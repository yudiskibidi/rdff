# node-rvn-bot

- Support: RVN
- OS     : Win, Linux, Macos
- Env    : Nodejs >= 16
